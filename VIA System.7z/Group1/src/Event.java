import java.util.ArrayList;
import java.io.Serializable;
/**
 * An abstract parent class, to hold all the values an event has.
 * @author Group1
 *
 */
public abstract class Event implements Serializable
{
   private String name;
   private String location;
   private Time duration;
   private String memberLimit;
   private boolean isFinalized;
   private Date date;
   private String price;
   private Lecturer lecturer;
   private Time scheduledTime;
   /**
    * A two argument constructor that sets the name and date of an event.
    * @param String name
    * @param Date date
    */
   public Event(String name, Date date) {
      this.name = name;
      this.date = date;
   }
   /**
    * A method that returns event name.
    * @return String
    */
   public String getName() {
      return name;
   }
   /**
    * A method that sets event name
    * @param String name
    */
   public void setName(String name) {
      this.name = name;
   }
   /**
    * A method that returns event location
    * @return String
    */
   public String getLocation() {
      return location;
   }
   /**
    * A method that sets event location
    * @param String location
    */
   public void setLocation(String location) {
      this.location = location;
   }
   /**
    * A method that returns event duration.
    * @return Time
    */
   public Time getDuration() {
      return duration;
   }
   /**
    * A method that sets event duration. Uses object from class Time.
    * @param Time duration
    */
   public void setDuration(Time duration) {
      this.duration = duration;
   }
   /**
    * A boolean that tells if the event is finalized.
    * If true then event is finalized.
    * @return boolean
    */
   public boolean isFinalized() {
      return isFinalized;
   }
   /**
    * A method that sets the event boolean isFinalized to true or false.
    * If true then event is finalized.
    * @param isFinalized
    */
   public void setFinalized(boolean isFinalized) {
      this.isFinalized = isFinalized;
   }
   /**
    * A method that returns event member limit.
    * @return String
    */
   public String getMemberLimit() {
      return memberLimit;
   }
   /**
    * A method that sets event member limit.
    * @param String memberLimit
    */
   public void setMemberLimit(String memberLimit) {
      this.memberLimit = memberLimit;
   }
   /**
    * A method that returns the event date in Date object format.
    * @return Date
    */
   public Date getDate() {
      return date;
   }
   /**
    * A method that sets the date of event in Date object formart
    * @param Date date
    */
   public void setDate(Date date) {
      this.date = date;
   }
   /**
    * A method that returns event price
    * @return String
    */
   public String getPrice() {
      return price;
   }
   /**
    * A method that sets event price.
    * @param String price
    */
   public void setPrice(String price) {
      this.price = price;
   }
   /**
    * A method that sets event lecturer of type Lecturer object
    * @param Lecturer lecturer
    */
   public void setLecturer(Lecturer lecturer) {
      this.lecturer = lecturer;
   }
   /**
    * A method that returns event lecturer of type Lecturer object.
    * @return Lecturer
    */
   public Lecturer getLecturer(){
      return lecturer;
   }
   /**
    * A method that sets event starting time of type Time object.
    * @param Time time
    */
   public void setScheduledTime(Time time) {
      scheduledTime = time;
   }
   /**
    * A method that returns event starting time of type Time object
    * @return Time
    */
   public Time getScheduledTime() {
      return scheduledTime;
   }
   /**
    * A method that returns every attribute of Event in a String format.
    */
   public String toString() {
      return "Name: " + name + ", Location: " + location +
            ", Duration: " + duration.toString() + ", Member limit: " + memberLimit + ", Price: " + price + ", Scheduled time: " +
            scheduledTime.toString() + ", Lecturer: " + lecturer.toString() + ", Date: " + date;
   }
   /**
    * An abstract method, that compares types of events.
    */
   public abstract boolean equals(Object obj);
   public abstract String getSubject();
   /**
    * An abstract method uses only in event types of Workshop and Journey
    * returns the ending date of event of type Date object
    * @return Date
    */
   public abstract Date getEndDate();
   public abstract String getDestination();
   /**
    * A method that returns all the attributes a Lecture has in a String format.
    * @return String
    */
   public String returnLecture() {
      return "Name: " + getName() + ", Subject: " + getSubject() + ", Date:" + getDate().toString() + ", Member limit: " + getMemberLimit() +
             ", Price: " + getPrice() + ", Lecturer: " + getLecturer().toString() + ", Starting time:" + getScheduledTime().toString();
   }
   /**
    * A method that returns all the attributes a Journey has in a String format.
    * @return String
    */
   public String returnJourney() {
      return "Name: " + getName() + ", Destination: " + getDestination() +
            ", Date:" + getDate().toString() + ", End date:" + getEndDate().toString()
            + ", Price:" + getPrice();
   }
   /**
    * A method that returns all the attributes a Workshop has in a String format.
    * @return String
    */
   public String returnWorkshop() {
      return "Name: " + getName() + ", Subject: " + getSubject() + ", Date:" + getDate().toString() + 
            ", Ending date:" + getEndDate().toString() + ", Member limit: " + getMemberLimit() + ", Price: "
            + getPrice() + ", Lecturer: " + getLecturer().toString()+ ", Starting time:" + getScheduledTime().toString() +
            ", Duration: " + getDuration().toString();
   }
   /**
    * A method that returns all the attributes a Seminar has in a String format.
    * @return String
    */
   public String returnSeminar() {
      return "Name: " + getName() + ", Subject: " + getSubject() +
            ", Date:" + getDate().toString() + ", Member limit: " + getMemberLimit()
            + ", Price: " + getPrice() + ", Lecturer: " + getLecturer().toString()
            + ", Starting time:" + getScheduledTime().toString();
   }
}
