import java.awt.event.*;
import java.io.IOException;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class SearchLecturerGUI extends JFrame
{
   private JButton edit;
   private JButton delete;
   private JList lecturerList;
   private JList specList;
   private JScrollPane lecturerScroll;
   private JScrollPane specScroll;
   private LecturerList lList;
   
   public SearchLecturerGUI() throws ClassNotFoundException, IOException{
      super("Search Lecturer");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() throws ClassNotFoundException, IOException {
      CompanyFile lecturerFile = new CompanyFile();        
      lList = lecturerFile.readLecturers();                  
      lecturerList = new JList(lList.returnLecturers());
      lecturerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      lecturerList.setLayoutOrientation(JList.VERTICAL);
      lecturerList.setVisibleRowCount(10);
      lecturerScroll = new JScrollPane(lecturerList);
      lecturerScroll.setPreferredSize(new Dimension(380, 320));
      edit = new JButton("Edit");
      delete = new JButton("Delete");
      String[] str = new String[lList.getLecturers().length];
      for(int i = 0; i < lList.getLecturers().length; i++) {
         str[i] = lList.getLecturers()[i].getSpecialization();
      }
      specList = new JList(str);
      specList.setPreferredSize(new Dimension(100, 100));
      specList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      specList.setLayoutOrientation(JList.VERTICAL);
      specScroll = new JScrollPane(specList);
   }
   private void initializeComponents() {
      setSize(550,400);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      edit.addActionListener(handler);
      delete.addActionListener(handler);
      specList.addListSelectionListener(new ListSelectionListener() {
         @Override
         public void valueChanged(ListSelectionEvent e)
         {
            String value = new String(specList.getSelectedValue().toString());
            LecturerList list = new LecturerList();
            for(int i = 0; i < lList.getLecturers().length; i++) {
               if(lList.getLecturers()[i].getSpecialization().equals(value)) {
               list.addLecturer(lList.getLecturers()[i]);
               }
            }
            lecturerList.setListData(list.returnLecturers());
            
         }
      });
   }
   private void addComponentsToFrame() {
      JPanel lecList = new JPanel(new FlowLayout());
      JPanel buttons = new JPanel(new GridLayout(0,1));
      JPanel main = new JPanel(new BorderLayout());
      
      //lecList
      lecList.add(lecturerScroll);
      //buttons
      buttons.add(specScroll);
      buttons.add(edit);
      buttons.add(delete);
      //main
      main.add(lecList, BorderLayout.WEST);
      main.add(buttons, BorderLayout.EAST);
      
      setContentPane(main);
   }
   
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == delete) {
            try
            {
               String str = lecturerList.getSelectedValue().toString();
               CompanyFile lecturerFile = new CompanyFile();
               LecturerList list = new LecturerList();
               list = lecturerFile.readLecturers();
               for(int i = 0; i < list.getLecturers().length;i++) {
                  if(str.equals(list.returnLecturers()[i])) {
                     list.removeLecturer(list.getLecturers()[i]);
                  }
               }
               lecturerFile.writeLecturers(list);
               lList = list;
               lecturerList.setListData(lList.returnLecturers());
               String[] string = new String[lList.getLecturers().length];
               for(int i = 0; i < lList.getLecturers().length; i++) {
                  string[i] = lList.getLecturers()[i].getSpecialization();
               }
               specList.setListData(string);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose a lecturer.");
            }
         }
         if(event.getSource() == edit) {
            try
            {
               CompanyFile lecturerFile = new CompanyFile();
               LecturerList list = new LecturerList();
               list = lecturerFile.readLecturers();
               for(int i = 0; i < list.getLecturers().length;i++) {
                  if(lecturerList.getSelectedValue().equals(list.returnLecturers()[i])) {
                     CreateLecturerGUI cl = new CreateLecturerGUI();
                     cl.setName(list.getLecturers()[i].getName());
                     cl.setPhone(list.getLecturers()[i].getPhoneNumber());
                     cl.setEmail(list.getLecturers()[i].getEmailAdress());
                     cl.setSalary(list.getLecturers()[i].getSalary());
                     cl.setSpec(list.getLecturers()[i].getSpecialization());
                     cl.setEdit(false);
                     list.removeLecturer(list.getLecturers()[i]);
                     lecturerFile.writeLecturers(list);
                     
                  }
               }
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose a lecturer.");
            }
         }
      }
   }

  
}
