import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class SearchSponsorGUI extends JFrame
{
   private JList sponsorsList;
   private JButton edit;
   private JButton delete;
   private JScrollPane scrollPane;
   
   public SearchSponsorGUI() throws ClassNotFoundException, IOException{
      super("Search Sponsor");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() throws ClassNotFoundException, IOException {
      CompanyFile file = new CompanyFile();
      sponsorsList = new JList(file.readSponsors().returnSponsors());
      sponsorsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      sponsorsList.setLayoutOrientation(JList.VERTICAL);
      sponsorsList.setVisibleRowCount(10);
      scrollPane = new JScrollPane(sponsorsList);
      scrollPane.setPreferredSize(new Dimension(400, 320));
      edit = new JButton("Edit");
      delete = new JButton("Delete");
   }
   private void initializeComponents() {
      setSize(500,380);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      edit.addActionListener(handler);
      delete.addActionListener(handler);
   }
   private void addComponentsToFrame() {
      JPanel list = new JPanel(new FlowLayout());
      JPanel buttonBox = new JPanel(new GridLayout(0,1));
      JPanel main = new JPanel(new BorderLayout());
      
      //list
      list.add(scrollPane);
      //buttonBox
      buttonBox.add(edit);
      buttonBox.add(delete);
      //main
      main.add(list, BorderLayout.WEST);
      main.add(buttonBox, BorderLayout.EAST);
      
      setContentPane(main);
   }
   
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == delete) {
            try
            {
               CompanyFile sponsorFile = new CompanyFile();
               SponsorList list = new SponsorList();
               list = sponsorFile.readSponsors();
               for(int i = 0; i < list.getSponsors().length;i++) {
                  if(sponsorsList.getSelectedValue().equals(list.returnSponsors()[i])) {
                     list.removeSponsor(list.getSponsors()[i]);
                  }
               }
               sponsorFile.writeSponsors(list);
               sponsorsList.setListData(sponsorFile.readSponsors().returnSponsors());
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose a sponsor.");
            }
         }
         if(event.getSource() == edit) {
            try
            {
               CompanyFile sponsorFile = new CompanyFile();
               SponsorList list = new SponsorList();
               list = sponsorFile.readSponsors();
               for(int i = 0; i < list.getSponsors().length;i++) {
                  if(sponsorsList.getSelectedValue().equals(list.returnSponsors()[i])) {
                     CreateSponsorGUI cs = new CreateSponsorGUI();
                     cs.setName(list.getSponsors()[i].getName());
                     cs.setPhone(list.getSponsors()[i].getPhoneNumber());
                     cs.setEmail(list.getSponsors()[i].getEmailAdress());
                     cs.setMoney(list.getSponsors()[i].getMoneyContributed());
                     cs.setEdit(false);
                     list.removeSponsor(list.getSponsors()[i]);
                     sponsorFile.writeSponsors(list);
                  }
               }
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose a sponsor.");
            }
         }
      }
   }
}
