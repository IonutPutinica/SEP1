import java.io.Serializable;
import java.util.ArrayList;
public class SponsorList implements Serializable
{
   private ArrayList<Sponsor> sponsors;
   
   public SponsorList() {
      sponsors = new ArrayList<Sponsor>();
   }
   
   public void addSponsor(Sponsor sponsor) {
      sponsors.add(sponsor);
   }
   public Sponsor[] getSponsors() {
      Sponsor[] sp = new Sponsor[sponsors.size()];
      for(int i = 0; i < sponsors.size(); i++) {
         sp[i] = sponsors.get(i);
      }
      return sp;
   }
   public void removeSponsor(Sponsor sponsor) {
      for(int i = 0; i < sponsors.size(); i++) {
         if(sponsor.equals(sponsors.get(i))) {
            sponsors.remove(i);
         }
      }
   }
   public String[] returnSponsors() {
      String[] str = new String[sponsors.size()];
      for(int i = 0; i < sponsors.size(); i++) {
            str[i] ="Name: " + sponsors.get(i).getName() + ", Phone number: " + sponsors.get(i).getPhoneNumber() +
                  ", Email adress: " + sponsors.get(i).getEmailAdress() + ", Money contributed: " + sponsors.get(i).getMoneyContributed();
      }
      return str;
   }
}