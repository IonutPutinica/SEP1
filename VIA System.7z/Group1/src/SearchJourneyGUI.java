import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class SearchJourneyGUI extends JFrame
{
   private JList journeysList;
   private JRadioButton finalized;
   private JRadioButton nonFinalized;
   private JRadioButton both;
   private ButtonGroup buttonGroup;
   private JButton edit;
   private JButton delete;
   private String[] eList;
   private JScrollPane lecturePane;
   
   public SearchJourneyGUI() throws ClassNotFoundException, IOException{
      super("Search Journey");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() throws ClassNotFoundException, IOException {
      CompanyFile file = new CompanyFile();
      eList = new String[file.readEvents().getJourneys().length];
      eList = file.readEvents().returnJourneys();
      journeysList = new JList(eList);
      lecturePane = new JScrollPane(journeysList);
      journeysList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      journeysList.setLayoutOrientation(JList.VERTICAL);
      journeysList.setVisibleRowCount(10);
      lecturePane.setPreferredSize(new Dimension(420, 320));
      finalized = new JRadioButton("Finalized");
      nonFinalized = new JRadioButton("Non-finalized");
      both = new JRadioButton("Show all");
      edit = new JButton("Edit");
      delete = new JButton("Delete");
      buttonGroup = new ButtonGroup();
      buttonGroup.add(both);
      buttonGroup.add(finalized);
      buttonGroup.add(nonFinalized);
      both.setSelected(true);
   }
   private void initializeComponents() {
      setSize(550,400);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      finalized.addActionListener(handler);
      nonFinalized.addActionListener(handler);
      both.addActionListener(handler);
      edit.addActionListener(handler);
      delete.addActionListener(handler);
      journeysList.addListSelectionListener(new ListSelectionListener() {
         @Override
         public void valueChanged(ListSelectionEvent e)
         {
            if(buttonGroup.getSelection().equals(finalized)) {
               try
               {
                  CompanyFile file = new CompanyFile();
                  EventList list = new EventList();
                  for(int i = 0;i < file.readEvents().returnFinalized().length;i++) {
                     if(file.readEvents().returnFinalized()[i].equals(new Journey("asd", new Date(1,1,1)))) {
                        list.addEvent(file.readEvents().returnFinalized()[i]);
                     }
                  }
                  eList = new String[list.getEvents().length];
                  for(int i = 0;i < list.getEvents().length;i++) {   
                        eList[i] = list.getEvents()[i].returnJourney();
                  }
                  journeysList.setListData(eList);
               }
               catch (ClassNotFoundException | IOException e1)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            if(buttonGroup.getSelection().equals(nonFinalized)) {
               try
               {
                  CompanyFile file = new CompanyFile();
                  EventList list = new EventList();
                  for(int i = 0;i < file.readEvents().returnNonFinalized().length;i++) {
                     if(file.readEvents().returnNonFinalized()[i].equals(new Journey("asd", new Date(1,1,1)))) {
                        list.addEvent(file.readEvents().returnNonFinalized()[i]);
                     }
                  }
                  eList = new String[list.getEvents().length];
                  for(int i = 0;i < list.getEvents().length;i++) {   
                        eList[i] = list.getEvents()[i].returnJourney();
                  }
                  journeysList.setListData(eList);
               }
               catch (ClassNotFoundException | IOException e2)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            if(buttonGroup.getSelection().equals(both)) {
               CompanyFile file = new CompanyFile();
               try
               {
                  journeysList.setListData(file.readEvents().returnJourneys());
               }
               catch (ClassNotFoundException | IOException e3)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            
         }
      });
   }
   private void addComponentsToFrame() {
      JPanel list = new JPanel(new FlowLayout());
      JPanel buttonBox = new JPanel(new GridLayout(0,1));
      JPanel main = new JPanel(new BorderLayout());
      
      //list
      list.add(lecturePane);
      //buttonBox
      buttonBox.add(finalized);
      buttonBox.add(nonFinalized);
      buttonBox.add(both);
      buttonBox.add(edit);
      buttonBox.add(delete);
      //main
      main.add(list, BorderLayout.WEST);
      main.add(buttonBox, BorderLayout.EAST);
      
      setContentPane(main);
   }
   
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == finalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnFinalized().length;i++) {
                  if(file.readEvents().returnFinalized()[i].equals(new Journey("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnJourney();
               }
               journeysList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == nonFinalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnNonFinalized().length;i++) {
                  if(file.readEvents().returnNonFinalized()[i].equals(new Journey("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnNonFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnJourney();
               }
               journeysList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == both) {
            CompanyFile file = new CompanyFile();
            try
            {
               String[] eList = file.readEvents().returnJourneys();
               journeysList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == edit) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               list = file.readEvents();
               for(int i = 0; i < list.getJourneys().length;i++) {
                  if(journeysList.getSelectedValue().equals(list.returnJourneys()[i])) {
                     if(list.getJourneys()[i].isFinalized()==true) {
                        JOptionPane.showMessageDialog(null,"Event is finalized.");
                     }
                     else {
                     CreateJourneyGUI cj = new CreateJourneyGUI();
                     cj.setName(list.getJourneys()[i].getName());
                     cj.setEventDay(list.getJourneys()[i].getDate().getDay());
                     cj.setEventMonth(list.getJourneys()[i].getDate().getMonth());
                     cj.setEventYear(list.getJourneys()[i].getDate().getYear());
                     cj.setEventEndDay(list.getJourneys()[i].getEndDate().getDay());
                     cj.setEventEndMonth(list.getJourneys()[i].getEndDate().getMonth());
                     cj.setEventEndYear(list.getJourneys()[i].getEndDate().getYear());
                     cj.setLocation(list.getJourneys()[i].getLocation());
                     cj.setMemberLimit(list.getJourneys()[i].getMemberLimit());
                     cj.setEventPrice(list.getJourneys()[i].getPrice());
                     cj.setEdit(false);
                     list.removeEvent(list.getJourneys()[i]);
                     file.writeEvents(list);
                     }
                  }
               }
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
         if(event.getSource() == delete) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = file.readEvents();
               for(int i = 0; i < list.getJourneys().length;i++) {
                  if(journeysList.getSelectedValue().toString().equals(list.returnJourneys()[i]) && list.getJourneys()[i].equals(new Journey("asd", new Date(1,1,1))))
                  {
                        list.removeEvent(list.getJourneys()[i]);
                        eList = new String[list.returnJourneys().length];
                        eList = list.returnJourneys();
                        journeysList.setListData(eList);
                        break;
                  }
               }
               file.writeEvents(list);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
      }
   }
}
