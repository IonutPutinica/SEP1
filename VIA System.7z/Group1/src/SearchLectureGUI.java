import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class SearchLectureGUI extends JFrame
{
   private JList lecturesList;
   private JRadioButton finalized;
   private JRadioButton nonFinalized;
   private JRadioButton both;
   private ButtonGroup buttonGroup;
   private JButton edit;
   private JButton delete;
   private String[] eList;
   private JScrollPane lecturePane;
   
   public SearchLectureGUI() throws ClassNotFoundException, IOException{
      super("Search Lecture");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() throws ClassNotFoundException, IOException {
      CompanyFile file = new CompanyFile();
      eList = new String[file.readEvents().getLectures().length];
      eList = file.readEvents().returnLectures();
      lecturesList = new JList(eList);
      lecturePane = new JScrollPane(lecturesList);
      lecturesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      lecturesList.setLayoutOrientation(JList.VERTICAL);
      lecturesList.setVisibleRowCount(10);
      lecturePane.setPreferredSize(new Dimension(450, 320));
      finalized = new JRadioButton("Finalized");
      nonFinalized = new JRadioButton("Non-finalized");
      both = new JRadioButton("Show all");
      edit = new JButton("Edit");
      delete = new JButton("Delete");
      buttonGroup = new ButtonGroup();
      buttonGroup.add(both);
      buttonGroup.add(finalized);
      buttonGroup.add(nonFinalized);
      both.setSelected(true);
   }
   private void initializeComponents() {
      setSize(600,400);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      finalized.addActionListener(handler);
      nonFinalized.addActionListener(handler);
      both.addActionListener(handler);
      edit.addActionListener(handler);
      delete.addActionListener(handler);
   }
   private void addComponentsToFrame() {
      JPanel list = new JPanel(new FlowLayout());
      JPanel buttonBox = new JPanel(new GridLayout(0,1));
      JPanel main = new JPanel(new BorderLayout());
      
      //list
      list.add(lecturePane);
      //buttonBox
      buttonBox.add(finalized);
      buttonBox.add(nonFinalized);
      buttonBox.add(both);
      buttonBox.add(edit);
      buttonBox.add(delete);
      //main
      main.add(list, BorderLayout.WEST);
      main.add(buttonBox, BorderLayout.EAST);
      
      setContentPane(main);
   }
   
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == finalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnFinalized().length;i++) {
                  if(file.readEvents().returnFinalized()[i].equals(new Lecture("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnLecture();
               }
               lecturesList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == nonFinalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnNonFinalized().length;i++) {
                  if(file.readEvents().returnNonFinalized()[i].equals(new Lecture("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnNonFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnLecture();
               }
               lecturesList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == both) {
            CompanyFile file = new CompanyFile();
            try
            {
               String[] eList = file.readEvents().returnLectures();
               lecturesList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == edit) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               list = file.readEvents();
               for(int i = 0; i < list.getLectures().length;i++) {
                  if(lecturesList.getSelectedValue().equals(list.returnLectures()[i])) {
                     if(list.getLectures()[i].isFinalized()==true) {
                        JOptionPane.showMessageDialog(null,"Event is finalized.");
                     }
                     else {
                     CreateLectureGUI cl = new CreateLectureGUI();
                     cl.setName(list.getLectures()[i].getName());
                     cl.setSubject(list.getLectures()[i].getSubject());
                     cl.setEventDay(list.getLectures()[i].getDate().getDay());
                     cl.setEventMonth(list.getLectures()[i].getDate().getMonth());
                     cl.setEventYear(list.getLectures()[i].getDate().getYear());
                     cl.setEventHour(list.getLectures()[i].getScheduledTime().getHour());
                     cl.setEventMinute(list.getLectures()[i].getScheduledTime().getMinute());
                     cl.setLocation(list.getLectures()[i].getLocation());
                     cl.setEventDurationHour(list.getLectures()[i].getDuration().getHour());
                     cl.setEventDurationMinute(list.getLectures()[i].getDuration().getMinute());
                     cl.setMemberLimit(list.getLectures()[i].getMemberLimit());
                     cl.setEventPrice(list.getLectures()[i].getPrice());
                     cl.setEdit(false);
                     list.removeEvent(list.getLectures()[i]);
                     file.writeEvents(list);
                     lecturesList.setListData(list.returnLectures());
                     break;
                     }
                  }
               }
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
         if(event.getSource() == delete) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = file.readEvents();
               for(int i = 0; i < list.getLectures().length;i++) {
                  if(lecturesList.getSelectedValue().toString().equals(list.returnLectures()[i]) && list.getLectures()[i].equals(new Lecture("asd", new Date(1,1,1))))
                  {
                        list.removeEvent(list.getLectures()[i]);
                        eList = new String[list.returnLectures().length];
                        eList = list.returnLectures();
                        lecturesList.setListData(eList);
                        break;
                  }
               }
               file.writeEvents(list);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
      }
   }
}
