import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
/**
 * Create Event GUI that creates event of type Workshop
 * @author Group1 
 *
 */
public class CreateWorkshopGUI extends JFrame
{
   private JTextField eventName;
   private JLabel eventNameLabel;
   private JTextField eventSubject;
   private JLabel eventSubjectLabel;
   private JTextField eventDateDay;
   private JLabel eventDateDayLabel;
   private JTextField eventDateMonth;
   private JLabel eventDateMonthLabel;
   private JTextField eventDateYear;
   private JLabel eventDateYearLabel;
   private JLabel eventStartLabel;
   private JTextField eventStartHour;
   private JLabel eventStartHourLabel;
   private JTextField eventStartMinute;
   private JLabel eventStartMinuteLabel;
   private JTextField eventEndDateDay;
   private JLabel eventEndDateDayLabel;
   private JTextField eventEndDateMonth;
   private JLabel eventEndDateMonthLabel;
   private JTextField eventEndDateYear;
   private JLabel eventEndDateYearLabel;
   private JTextField eventLocation;
   private JLabel eventLocationLabel;
   private JTextField eventDurationHour;
   private JLabel eventDurationHourLabel;
   private JTextField eventDurationMinute;
   private JLabel eventDurationMinuteLabel;
   private JTextField memberLimit;
   private JLabel memberLimitLabel;
   private JTextField eventPrice;
   private JLabel eventPriceLabel;
   private JLabel eventLecturerLabel;
   private JLabel eventDateLabel;
   private JLabel eventEndDateLabel;
   private JLabel eventDurationLabel;
   private JButton save;
   private JButton close;
   private JButton finalize;
   private JButton clear;
   private JList lecturerList;
   private JScrollPane lecturerPane;
   private LecturerList lList;
   /**
    * A constructor that loads all the components of the CreateWorkshopGUI
    * @throws ClassNotFoundException
    * @throws IOException
    */
   public CreateWorkshopGUI() throws ClassNotFoundException, IOException {
      super("Create Workshop");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   /**
    * A method that sets the values of all JFrame elements.
    * @throws ClassNotFoundException
    * @throws IOException
    */
   private void createComponents() throws ClassNotFoundException, IOException {
      eventName = new JTextField(30);
      eventNameLabel = new JLabel("Event name:");
      eventSubject = new JTextField(30);
      eventSubjectLabel = new JLabel("Event subject:");
      eventDateLabel = new JLabel("Date of event:", JLabel.CENTER);
      eventDateDay = new JTextField(2);
      eventDateDayLabel = new JLabel("Day:");
      eventDateMonth = new JTextField(2);
      eventDateMonthLabel = new JLabel("Month:");
      eventDateYear = new JTextField(4);
      eventDateYearLabel = new JLabel("Year:");
      eventStartLabel = new JLabel("Time event starts:", JLabel.CENTER);
      eventStartHour = new JTextField(2);
      eventStartHourLabel = new JLabel("Hour:");
      eventStartMinute = new JTextField(2);
      eventStartMinuteLabel = new JLabel("Minute:");
      eventEndDateLabel = new JLabel("End date of event:",JLabel.CENTER);
      eventEndDateDay = new JTextField(2);
      eventEndDateDayLabel = new JLabel("Day:");
      eventEndDateMonth = new JTextField(2);
      eventEndDateMonthLabel = new JLabel("Month:");
      eventEndDateYear = new JTextField(4);
      eventEndDateYearLabel = new JLabel("Year:");
      eventLocation = new JTextField(30);
      eventLocationLabel = new JLabel("Event location:");
      eventDurationLabel = new JLabel("Event duration:", JLabel.CENTER);
      eventDurationHour = new JTextField(2);
      eventDurationHourLabel = new JLabel("Hour: ");
      eventDurationMinute = new JTextField(2);
      eventDurationMinuteLabel = new JLabel("Minute:");
      memberLimit = new JTextField(3);
      memberLimitLabel = new JLabel("Member limit:");
      eventPrice = new JTextField(8);
      eventPriceLabel = new JLabel("Price:");
      eventLecturerLabel = new JLabel("Assign a lecturer:");
      CompanyFile file = new CompanyFile();
      lList = file.readLecturers();
      lecturerList = new JList(lList.returnLecturers());
      lecturerPane = new JScrollPane(lecturerList);
      lecturerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      lecturerList.setLayoutOrientation(JList.VERTICAL);
      lecturerList.setVisibleRowCount(4);
      lecturerPane.setPreferredSize(new Dimension(50, 50));
      save = new JButton("Save");
      close = new JButton("Close");
      finalize = new JButton("Finalize event");
      clear = new JButton("Clear all");
   }
   /**
    * A method that sets the properties of the main frame.
    * Sets the size, visibility and location to the center of the screen.
    * Sets the default closing operation to dispose on close.
    */
   private void initializeComponents() {
      setSize(600,950);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   /**
    * A method that creates an instance of the private class"ButtonHandler"
    * and adds an action listener to every button in the CreateWorkshopGUI class
    */
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      close.addActionListener(handler);
      save.addActionListener(handler);
      finalize.addActionListener(handler);
      clear.addActionListener(handler);
   }
   /**
    * A method that places all the components in the main frame.
    */
   private void addComponentsToFrame() {
      JPanel main = new JPanel(new BorderLayout());
      JPanel name = new JPanel(new FlowLayout());
      JPanel nameBox = new JPanel(new BorderLayout());
      JPanel nameBoxContainer = new JPanel(new BorderLayout());
      JPanel subject = new JPanel(new FlowLayout());
      JPanel subjectBox = new JPanel(new BorderLayout());
      JPanel dateValues = new JPanel(new FlowLayout());
      JPanel dateBox = new JPanel(new BorderLayout());
      JPanel startValues = new JPanel(new FlowLayout());
      JPanel startValuesBox = new JPanel(new BorderLayout());
      JPanel endDateValues = new JPanel(new FlowLayout());
      JPanel endDateBox = new JPanel(new BorderLayout());
      JPanel location = new JPanel(new FlowLayout());
      JPanel locationBox = new JPanel(new BorderLayout());
      JPanel locationBoxContainer = new JPanel(new BorderLayout());
      JPanel durationValues = new JPanel(new FlowLayout());
      JPanel durationBox = new JPanel(new BorderLayout());
      JPanel mLimit = new JPanel(new FlowLayout());
      JPanel mLimitBox = new JPanel(new BorderLayout());
      JPanel mLimitBoxContainer = new JPanel(new BorderLayout());
      JPanel price = new JPanel(new FlowLayout());
      JPanel priceBox = new JPanel(new BorderLayout());
      JPanel lecturer = new JPanel(new FlowLayout());
      JPanel lecturerContainer = new JPanel(new BorderLayout());
      JPanel middle = new JPanel(new GridLayout(10,1));
      JPanel middleBox = new JPanel(new FlowLayout());
      JPanel buttons = new JPanel(new FlowLayout());
      
      //name
      name.add(eventNameLabel);
      name.add(eventName);
      //nameBox
      nameBox.add(name, BorderLayout.NORTH);
      //subject
      subject.add(eventSubjectLabel);
      subject.add(eventSubject);
      //subjectBox
      subjectBox.add(subject, BorderLayout.CENTER);
      subjectBox.add(new JSeparator(), BorderLayout.SOUTH);
      //nameBoxContainer
      nameBoxContainer.add(nameBox, BorderLayout.CENTER);
      nameBoxContainer.add(new JSeparator(), BorderLayout.SOUTH);
      //dateValues
      dateValues.add(eventDateDayLabel);
      dateValues.add(eventDateDay);
      dateValues.add(eventDateMonthLabel);
      dateValues.add(eventDateMonth);
      dateValues.add(eventDateYearLabel);
      dateValues.add(eventDateYear);
      //dateBox
      dateBox.add(eventDateLabel, BorderLayout.NORTH);
      dateBox.add(dateValues, BorderLayout.CENTER);
      //dateValues
      dateValues.add(eventDateDayLabel);
      dateValues.add(eventDateDay);
      dateValues.add(eventDateMonthLabel);
      dateValues.add(eventDateMonth);
      dateValues.add(eventDateYearLabel);
      dateValues.add(eventDateYear);
      //dateBox
      dateBox.add(eventDateLabel, BorderLayout.NORTH);
      dateBox.add(dateValues, BorderLayout.CENTER);
      //startValues
      startValues.add(eventStartHourLabel);
      startValues.add(eventStartHour);
      startValues.add(eventStartMinuteLabel);
      startValues.add(eventStartMinute);
      //startValuesBox
      startValuesBox.add(eventStartLabel, BorderLayout.NORTH);
      startValuesBox.add(startValues, BorderLayout.CENTER);
      //endDateValues
      endDateValues.add(eventEndDateDayLabel);
      endDateValues.add(eventEndDateDay);
      endDateValues.add(eventEndDateMonthLabel);
      endDateValues.add(eventEndDateMonth);
      endDateValues.add(eventEndDateYearLabel);
      endDateValues.add(eventEndDateYear);
      //endDateBox
      endDateBox.add(new JSeparator(), BorderLayout.NORTH);
      endDateBox.add(eventEndDateLabel, BorderLayout.CENTER);
      endDateBox.add(endDateValues, BorderLayout.SOUTH);
      //location
      location.add(eventLocationLabel);
      location.add(eventLocation);
      //locationBox
      locationBox.add(location, BorderLayout.CENTER);
      //locationBoxContainer
      locationBoxContainer.add(new JSeparator(), BorderLayout.NORTH);
      locationBoxContainer.add(locationBox, BorderLayout.CENTER);
      locationBoxContainer.add(new JSeparator(), BorderLayout.SOUTH);
      //durationValues
      durationValues.add(eventDurationHourLabel);
      durationValues.add(eventDurationHour);
      durationValues.add(eventDurationMinuteLabel);
      durationValues.add(eventDurationMinute);
      //durationBox
      durationBox.add(eventDurationLabel, BorderLayout.NORTH);
      durationBox.add(durationValues, BorderLayout.CENTER);
      //mLimit
      mLimit.add(memberLimitLabel);
      mLimit.add(memberLimit);
      //mLimitBox
      mLimitBox.add(mLimit, BorderLayout.CENTER);
      //mLimitBoxContainer
      mLimitBoxContainer.add(new JSeparator(), BorderLayout.NORTH);
      mLimitBoxContainer.add(mLimitBox, BorderLayout.CENTER);
      mLimitBoxContainer.add(new JSeparator(), BorderLayout.SOUTH);
      //price
      price.add(eventPriceLabel);
      price.add(eventPrice);
      //priceBox
      priceBox.add(price, BorderLayout.CENTER);
      //lecturer
      lecturer.add(eventLecturerLabel);
      //lecturerContainer
      lecturerContainer.add(new JSeparator(), BorderLayout.NORTH);
      lecturerContainer.add(lecturer, BorderLayout.CENTER);
      lecturerContainer.add(lecturerPane, BorderLayout.SOUTH);
      //middle
      middle.add(nameBoxContainer);
      middle.add(subjectBox);
      middle.add(dateBox);
      middle.add(startValuesBox);
      middle.add(endDateBox);
      middle.add(locationBoxContainer);
      middle.add(durationBox);
      middle.add(mLimitBoxContainer);
      middle.add(priceBox);
      middle.add(lecturerContainer);
      //buttons
      buttons.add(save);
      buttons.add(close);
      buttons.add(clear);
      buttons.add(finalize);
      //middleBox
      middleBox.add(middle);
      //main
      main.add(middleBox, BorderLayout.CENTER);
      main.add(buttons, BorderLayout.SOUTH);
      
      setContentPane(main);
   }
   /**
    * A method that sets the String value in JTextField eventName when the class is instantiated.
    * @param String s
    */
   public void setName(String s) {
      eventName.setText(s);
   }
   /**
    * A method that sets the String value in JTextField eventSubject when the class is instantiated.
    * @param String s
    */
   public void setSubject(String s) {
      eventSubject.setText(s);
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventDateDay
    * @param int i
    */
   public void setEventDay(int i) {
      eventDateDay.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventDateMonth
    * @param int i
    */
   public void setEventMonth(int i) {
      eventDateMonth.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventDateYear
    * @param int i
    */
   public void setEventYear(int i) {
      eventDateYear.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventEndDateDay
    * @param int i
    */
   public void setEventEndDay(int i) {
      eventEndDateDay.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventEndDateMonth
    * @param int i
    */
   public void setEventEndMonth(int i) {
      eventEndDateMonth.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventEndDateYear
    * @param int i
    */
   public void setEventEndYear(int i) {
      eventEndDateYear.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventStartHour
    * @param int i
    */
   public void setEventHour(int i) {
      eventStartHour.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventStartMinute
    * @param int i
    */
   public void setEventMinute(int i) {
      eventStartMinute.setText(Integer.toString(i));
   }
   /**
    * A method that sets the String value in JTextField eventLocation when the class is instantiated.
    * @param String s
    */
   public void setLocation(String s) {
      eventLocation.setText(s);
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventDurationHour
    * @param int i
    */
   public void setEventDurationHour(int i) {
      eventDurationHour.setText(Integer.toString(i));
   }
   /**
    * A method that parses an integer to a String and sets the value to the String value of
    * JTextFiel eventDurationMinute
    * @param int i
    */
   public void setEventDurationMinute(int i) {
      eventDurationMinute.setText(Integer.toString(i));
   }
   /**
    * A method that sets the String value in JTextField memberLimit when the class is instantiated.
    * @param String s
    */
   public void setMemberLimit(String s) {
      memberLimit.setText(s);
   }
   /**
    * A method that sets the String value in JTextField eventPrice when the class is instantiated.
    * @param String s
    */
   public void setEventPrice(String s) {
      eventPrice.setText(s);
   }
   /**
    * A method which sets the close button's visibility to false. Used when editing an event
    * in order to avoid losing information.
    * @param boolean b
    */
   public void setEdit(boolean b) {
      close.setVisible(b);
   }
   /**
    * A private class for the event handlers.
    * @author user
    *
    */
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == close) {
            dispose();
         }
         if(event.getSource() == clear) {
            eventName.setText("");
            eventDateDay.setText("");
            eventDateMonth.setText("");
            eventDateYear.setText("");
            eventEndDateDay.setText("");
            eventEndDateMonth.setText("");
            eventEndDateYear.setText("");
            eventLocation.setText("");
            eventDurationHour.setText("");
            eventDurationMinute.setText("");
            memberLimit.setText("");
            eventPrice.setText("");
            eventSubject.setText("");
            eventStartHour.setText("");
            eventStartMinute.setText("");
            
         }
         if(event.getSource() == save) {
            try{
               if(lecturerList.isSelectionEmpty()) {
                  JOptionPane.showMessageDialog(null, "Please asign a lecturer");
               }
               else {
               Date date = new Date(Integer.parseInt(eventDateDay.getText()),Integer.parseInt(eventDateMonth.getText()),
                  Integer.parseInt(eventDateYear.getText()));
               Time start = new Time(Integer.parseInt(eventStartHour.getText()),Integer.parseInt(eventStartMinute.getText()));
               Time duration = new Time(Integer.parseInt(eventDurationHour.getText()), Integer.parseInt(eventStartMinute.getText()));
               Date end = new Date(Integer.parseInt(eventEndDateDay.getText()),
                     Integer.parseInt(eventEndDateMonth.getText()),Integer.parseInt(eventEndDateYear.getText()));
               Workshop workshop = new Workshop(eventName.getText(), date);
               workshop.setEndDate(end);
               workshop.setSubject(eventSubject.getText());
               workshop.setLocation(eventLocation.getText());
               workshop.setDuration(duration);
               workshop.setMemberLimit(memberLimit.getText());
               workshop.setPrice(eventPrice.getText());
               workshop.setScheduledTime(start);
               CompanyFile eventFile = new CompanyFile();
               for(int i = 0; i < eventFile.readLecturers().returnLecturers().length;i++) {
                  if(eventFile.readLecturers().returnLecturers()[i].equals(lecturerList.getSelectedValue())) {
                     workshop.setLecturer(eventFile.readLecturers().getLecturers()[i]);
                  }
               }
               EventList list = new EventList();
               list = eventFile.readEvents();
               list.addEvent(workshop);
               eventFile.writeEvents(list);
               dispose();
            }
            }
            catch (ClassNotFoundException | IOException e){
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch(NumberFormatException e) {
               JOptionPane.showMessageDialog(null,"Invalid starting date values, ending date values or time values.");
            }
         }
         if(event.getSource() == finalize) {
            try{
               if(lecturerList.isSelectionEmpty()) {
                  JOptionPane.showMessageDialog(null, "Please asign a lecturer");
               }
               else {
               Date date = new Date(Integer.parseInt(eventDateDay.getText()),Integer.parseInt(eventDateMonth.getText()),
                  Integer.parseInt(eventDateYear.getText()));
               Time start = new Time(Integer.parseInt(eventStartHour.getText()),Integer.parseInt(eventStartMinute.getText()));
               Time duration = new Time(Integer.parseInt(eventDurationHour.getText()), Integer.parseInt(eventStartMinute.getText()));
               Date end = new Date(Integer.parseInt(eventEndDateDay.getText()),
                     Integer.parseInt(eventEndDateMonth.getText()),Integer.parseInt(eventEndDateYear.getText()));
               Workshop workshop = new Workshop(eventName.getText(), date);
               workshop.setEndDate(end);
               workshop.setSubject(eventSubject.getText());
               workshop.setLocation(eventLocation.getText());
               workshop.setDuration(duration);
               workshop.setMemberLimit(memberLimit.getText());
               workshop.setPrice(eventPrice.getText());
               workshop.setScheduledTime(start);
               workshop.setFinalized(true);
               CompanyFile eventFile = new CompanyFile();
               for(int i = 0; i < eventFile.readLecturers().returnLecturers().length;i++) {
                  if(eventFile.readLecturers().returnLecturers()[i].equals(lecturerList.getSelectedValue())) {
                     workshop.setLecturer(eventFile.readLecturers().getLecturers()[i]);
                  }
               }
               EventList list = new EventList();
               list = eventFile.readEvents();
               list.addEvent(workshop);
               eventFile.writeEvents(list);
               dispose();
            }
            }
            catch (ClassNotFoundException | IOException e){
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch(NumberFormatException e) {
               JOptionPane.showMessageDialog(null,"Invalid starting date values, ending date values or time values.");
            }
         }
      }
   }
}
