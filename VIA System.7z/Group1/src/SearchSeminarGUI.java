import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class SearchSeminarGUI extends JFrame
{
   private JList seminarsList;
   private JRadioButton finalized;
   private JRadioButton nonFinalized;
   private JRadioButton both;
   private ButtonGroup buttonGroup;
   private JButton edit;
   private JButton delete;
   private String[] eList;
   private JScrollPane lecturePane;
   
   public SearchSeminarGUI() throws ClassNotFoundException, IOException{
      super("Search Seminar");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() throws ClassNotFoundException, IOException {
      CompanyFile file = new CompanyFile();
      eList = new String[file.readEvents().getSeminars().length];
      eList = file.readEvents().returnSeminars();
      seminarsList = new JList(eList);
      lecturePane = new JScrollPane(seminarsList);
      seminarsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      seminarsList.setLayoutOrientation(JList.VERTICAL);
      seminarsList.setVisibleRowCount(10);
      lecturePane.setPreferredSize(new Dimension(450, 320));
      finalized = new JRadioButton("Finalized");
      nonFinalized = new JRadioButton("Non-finalized");
      both = new JRadioButton("Show all");
      edit = new JButton("Edit");
      delete = new JButton("Delete");
      buttonGroup = new ButtonGroup();
      buttonGroup.add(both);
      buttonGroup.add(finalized);
      buttonGroup.add(nonFinalized);
      both.setSelected(true);
   }
   private void initializeComponents() {
      setSize(600,400);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      finalized.addActionListener(handler);
      nonFinalized.addActionListener(handler);
      both.addActionListener(handler);
      edit.addActionListener(handler);
      delete.addActionListener(handler);
      seminarsList.addListSelectionListener(new ListSelectionListener() {
         @Override
         public void valueChanged(ListSelectionEvent e)
         {
            if(buttonGroup.getSelection().equals(finalized)) {
               try
               {
                  CompanyFile file = new CompanyFile();
                  EventList list = new EventList();
                  for(int i = 0;i < file.readEvents().returnFinalized().length;i++) {
                     if(file.readEvents().returnFinalized()[i].equals(new Seminar("asd", new Date(1,1,1)))) {
                        list.addEvent(file.readEvents().returnFinalized()[i]);
                     }
                  }
                  eList = new String[list.getEvents().length];
                  for(int i = 0;i < list.getEvents().length;i++) {   
                        eList[i] = list.getEvents()[i].returnSeminar();
                  }
                  seminarsList.setListData(eList);
               }
               catch (ClassNotFoundException | IOException e1)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            if(buttonGroup.getSelection().equals(nonFinalized)) {
               try
               {
                  CompanyFile file = new CompanyFile();
                  EventList list = new EventList();
                  for(int i = 0;i < file.readEvents().returnNonFinalized().length;i++) {
                     if(file.readEvents().returnNonFinalized()[i].equals(new Seminar("asd", new Date(1,1,1)))) {
                        list.addEvent(file.readEvents().returnNonFinalized()[i]);
                     }
                  }
                  eList = new String[list.getEvents().length];
                  for(int i = 0;i < list.getEvents().length;i++) {   
                        eList[i] = list.getEvents()[i].returnSeminar();
                  }
                  seminarsList.setListData(eList);
               }
               catch (ClassNotFoundException | IOException e2)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            if(buttonGroup.getSelection().equals(both)) {
               CompanyFile file = new CompanyFile();
               try
               {
                  eList = file.readEvents().returnSeminars();
                  seminarsList.setListData(eList);
               }
               catch (ClassNotFoundException | IOException e3)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            
         }
      });
   }
   private void addComponentsToFrame() {
      JPanel list = new JPanel(new FlowLayout());
      JPanel buttonBox = new JPanel(new GridLayout(0,1));
      JPanel main = new JPanel(new BorderLayout());
      
      //list
      list.add(lecturePane);
      //buttonBox
      buttonBox.add(finalized);
      buttonBox.add(nonFinalized);
      buttonBox.add(both);
      buttonBox.add(edit);
      buttonBox.add(delete);
      //main
      main.add(list, BorderLayout.WEST);
      main.add(buttonBox, BorderLayout.EAST);
      
      setContentPane(main);
   }
   
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == finalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnFinalized().length;i++) {
                  if(file.readEvents().returnFinalized()[i].equals(new Seminar("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnSeminar();
               }
               seminarsList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == nonFinalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnNonFinalized().length;i++) {
                  if(file.readEvents().returnNonFinalized()[i].equals(new Seminar("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnNonFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnSeminar();
               }
               seminarsList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == both) {
            CompanyFile file = new CompanyFile();
            try
            {
               eList = file.readEvents().returnSeminars();
               seminarsList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == edit) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               list = file.readEvents();
               for(int i = 0; i < list.getSeminars().length;i++) {
                  if(seminarsList.getSelectedValue().toString().equals(list.returnSeminars()[i])) {
                     if(list.getSeminars()[i].isFinalized()==true) {
                        JOptionPane.showMessageDialog(null,"Event is finalized.");
                     }
                     else {
                     CreateSeminarGUI cs = new CreateSeminarGUI();
                     cs.setName(list.getSeminars()[i].getName());
                     cs.setSubject(list.getSeminars()[i].getSubject());
                     cs.setEventDay(list.getSeminars()[i].getDate().getDay());
                     cs.setEventMonth(list.getSeminars()[i].getDate().getMonth());
                     cs.setEventYear(list.getSeminars()[i].getDate().getYear());
                     cs.setEventHour(list.getSeminars()[i].getScheduledTime().getHour());
                     cs.setEventMinute(list.getSeminars()[i].getScheduledTime().getMinute());
                     cs.setLocation(list.getSeminars()[i].getLocation());
                     cs.setEventDurationHour(list.getSeminars()[i].getDuration().getHour());
                     cs.setEventDurationMinute(list.getSeminars()[i].getDuration().getMinute());
                     cs.setMemberLimit(list.getSeminars()[i].getMemberLimit());
                     cs.setEventPrice(list.getSeminars()[i].getPrice());
                     cs.setEdit(false);
                     list.removeEvent(list.getSeminars()[i]);
                     file.writeEvents(list);
                     seminarsList.setListData(list.returnSeminars());
                     break;
                     }
                  }
               }
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
         if(event.getSource() == delete) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = file.readEvents();
               for(int i = 0; i < list.getSeminars().length;i++) {
                  if(seminarsList.getSelectedValue().toString().equals(list.returnSeminars()[i]) && list.getSeminars()[i].equals(new Seminar("asd", new Date(1,1,1))))
                  {
                        list.removeEvent(list.getSeminars()[i]);
                        eList = new String[list.returnSeminars().length];
                        eList = list.returnSeminars();
                        seminarsList.setListData(eList);
                        break;
                  }
               }
               file.writeEvents(list);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
      }
   }
}
