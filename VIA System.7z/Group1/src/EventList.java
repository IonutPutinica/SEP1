import java.io.Serializable;
import java.util.ArrayList;
/**
 * A class that holds an array list of type "Event".
 * Used for writing events to files and displaying them in JList.
 * @author Group1
 *
 */
public class EventList implements Serializable
{
   private ArrayList<Event> events;
   /**
    * Initializes the array list
    */
   public EventList() {
      events = new ArrayList<Event>();
   }
   /**
    * Adds an event to the event array list
    * @param Event event
    */
   public void addEvent(Event event) {
      events.add(event);
   }
   /**
    * Returns all the events stored in the private array list.
    * @return Event[]
    */
   public Event[] getEvents() {
      Event[] ev = new Event[events.size()];
      for(int i = 0; i < events.size(); i++) {
         ev[i] = events.get(i);
      }
      return ev;
   }
   /**
    * Starts a loop that looks for the event given as an argument and removes it
    * from the private array list.
    * @param Event event
    */
   public void removeEvent(Event event) {
      for(int i = 0; i < events.size();i++) {
         if(event == events.get(i)) {
            events.remove(i);
         }
      }
   }
   /**
    * Returns all events of type "Lecture" from the private array list.
    * Uses a loop to identify the number of events of type "Lecture" in the private array list
    * and stores them into a separate array, which returns after the loop is finished.
    * @return Event[]
    */
   public Event[] getLectures() {                  
      Event x = new Lecture("pishle", new Date(1,1,1));
      ArrayList<Event> asd = new ArrayList<Event>();
      for(int i = 0; i < events.size(); i++) {
         if(x.equals(events.get(i))) {
            asd.add(events.get(i));
         }
      }
      Event[] lcs = new Lecture[asd.size()];
      for(int i = 0; i < asd.size(); i++) {
          
            lcs[i] = asd.get(i);
         
      }
      return lcs;
   }
   /**
    * Returns a String array containing all the information events of type "Lecture" have.
    * Used in JList.
    * @return String[]
    */
   public String[] returnLectures() {
      String[] str = new String[getLectures().length];
      for(int i = 0; i < getLectures().length;i++) {
         str[i] = "Name: " + getLectures()[i].getName() + ", Subject: " + getLectures()[i].getSubject() +
               ", Date:" + getLectures()[i].getDate().toString() + ", Member limit: " + getLectures()[i].getMemberLimit()
               + ", Price: " + getLectures()[i].getPrice() + ", Lecturer: " + getLectures()[i].getLecturer().toString() +
                ", Starting time:" + getLectures()[i].getScheduledTime().toString();
      }
      return str;
   }
   /**
    * Returns all events of type "Seminar" from the private array list.
    * Uses a loop to identify the number of events of type "Seminar" in the private array list
    * and stores them into a separate array, which returns after the loop is finished.
    * @return Event[]
    */
   public Event[] getSeminars() {                  
      Event x = new Seminar("pishle", new Date(1,1,1));
      ArrayList<Event> asd = new ArrayList<Event>();
      for(int i = 0; i < events.size(); i++) {
         if(x.equals(events.get(i))) {
            asd.add(events.get(i));
         }
      }
      Event[] lcs = new Seminar[asd.size()];
      for(int i = 0; i < asd.size(); i++) {
          
            lcs[i] = asd.get(i);
         
      }
      return lcs;
   }
   /**
    * Returns a String array containing all the information events of type "Seminar" have.
    * Used in JList.
    * @return String[]
    */
   public String[] returnSeminars() {
      String[] str = new String[getSeminars().length];
      for(int i = 0; i < getSeminars().length;i++) {
         str[i] = "Name: " + getSeminars()[i].getName() + ", Subject: " + getSeminars()[i].getSubject() +
               ", Date:" + getSeminars()[i].getDate().toString() + ", Member limit: " + getSeminars()[i].getMemberLimit()
               + ", Price: " + getSeminars()[i].getPrice() + ", Lecturer: " + getSeminars()[i].getLecturer().toString()
               + ", Starting time:" + getSeminars()[i].getScheduledTime().toString();
      }
      return str;
   }
   /**
    * Returns all events of type "Workshop" from the private array list.
    * Uses a loop to identify the number of events of type "Workshop" in the private array list
    * and stores them into a separate array, which returns after the loop is finished.
    * @return Event[]
    */
   public Event[] getWorkshops() {                  
      Event x = new Workshop("pishle", new Date(1,1,1));
      ArrayList<Event> asd = new ArrayList<Event>();
      for(int i = 0; i < events.size(); i++) {
         if(x.equals(events.get(i))) {
            asd.add(events.get(i));
         }
      }
      Event[] lcs = new Workshop[asd.size()];
      for(int i = 0; i < asd.size(); i++) {
          
            lcs[i] = asd.get(i);
         
      }
      return lcs;
   }
   /**
    * Returns a String array containing all the information events of type "Workshop" have.
    * Used in JList.
    * @return String[]
    */
   public String[] returnWorkshops() {
      String[] str = new String[getWorkshops().length];
      for(int i = 0; i < getWorkshops().length;i++) {
         str[i] = "Name: " + getWorkshops()[i].getName() + ", Subject: " + getWorkshops()[i].getSubject() + ", Date:" + 
               getWorkshops()[i].getDate().toString() + 
               ", Ending date:" + getWorkshops()[i].getEndDate().toString() + ", Member limit: " + 
               getWorkshops()[i].getMemberLimit() + ", Price: "
               + getWorkshops()[i].getPrice() + ", Lecturer: " + 
               getWorkshops()[i].getLecturer().toString()+ ", Starting time:" + 
               getWorkshops()[i].getScheduledTime().toString() +
               ", Duration: " + getWorkshops()[i].getDuration().toString();
      }
      return str;
   }
   /**
    * Returns all events of type "Journey" from the private array list.
    * Uses a loop to identify the number of events of type "Journey" in the private array list
    * and stores them into a separate array, which returns after the loop is finished.
    * @return Event[]
    */
   public Event[] getJourneys() {                  
      Event x = new Journey("pishle", new Date(1,1,1));
      ArrayList<Event> asd = new ArrayList<Event>();
      for(int i = 0; i < events.size(); i++) {
         if(x.equals(events.get(i))) {
            asd.add(events.get(i));
         }
      }
      Event[] lcs = new Journey[asd.size()];
      for(int i = 0; i < asd.size(); i++) {
          
            lcs[i] = asd.get(i);
         
      }
      return lcs;
   }
   /**
    * Returns a String array containing all the information events of type "Journey" have.
    * Used in JList.
    * @return String[]
    */
   public String[] returnJourneys() {
      String[] str = new String[getJourneys().length];
      for(int i = 0; i < getJourneys().length;i++) {
         str[i] = "Name: " + getJourneys()[i].getName() + ", Destination: " + getJourneys()[i].getDestination() +
               ", Date:" + getJourneys()[i].getDate().toString() + ", End date:" + getJourneys()[i].getEndDate().toString()
               + ", Price:" + getJourneys()[i].getPrice();
      }
      return str;
   }
   /**
    * Returns all events from the private array list, that have their property
    * "isFinalized" set to true.
    * @return Event[]
    */
   public Event[] returnFinalized() {
      ArrayList<Event> asd = new ArrayList<Event>();
      for(int i = 0; i < events.size(); i++) {
         if(events.get(i).isFinalized()==true) {
            asd.add(events.get(i));
         }
      }
      Event[] jns = new Event[asd.size()];
      for(int i = 0; i < asd.size(); i++) {
         jns[i] = asd.get(i);
      }
      return jns;
   }
   /**
    * Returns all events from the private array list, that have their property
    * "isFinalized" set to false.
    * @return Event[]
    */
   public Event[] returnNonFinalized() {
      ArrayList<Event> asd = new ArrayList<Event>();
      for(int i = 0; i < events.size(); i++) {
         if(events.get(i).isFinalized()==false) {
            asd.add(events.get(i));
         }
      }
      Event[] jns = new Event[asd.size()];
      for(int i = 0; i < asd.size(); i++) {
         jns[i] = asd.get(i);
      }
      return jns;
   }
}
