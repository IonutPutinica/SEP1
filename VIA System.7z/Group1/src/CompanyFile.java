import java.io.*;
import java.util.ArrayList;
public class CompanyFile
{
   private FileOutputStream outStream;
   private FileInputStream inStream;
   private ObjectOutputStream objectOutputFile;
   private ObjectInputStream objectInputFile;
   
   public CompanyFile() {
   
   }
   
   public void writeEvents(EventList list) throws IOException {
      outStream = new FileOutputStream("Event.bin");
      objectOutputFile = new ObjectOutputStream(outStream);
      objectOutputFile.writeObject(list);
      objectOutputFile.close();
   }
   
   public EventList readEvents() throws IOException, ClassNotFoundException {
      inStream = new FileInputStream("Event.bin");
      objectInputFile = new ObjectInputStream(inStream);  
      EventList e = new EventList();
      e = (EventList) objectInputFile.readObject();
      objectInputFile.close();
      return e;
   }
   
   public void writeMembers(MemberList list) throws IOException {
      outStream = new FileOutputStream("Member.bin");
      objectOutputFile = new ObjectOutputStream(outStream);
      objectOutputFile.writeObject(list);
      objectOutputFile.close();
   }
   public MemberList readMembers() throws IOException, ClassNotFoundException {
      inStream = new FileInputStream("Member.bin");
      objectInputFile = new ObjectInputStream(inStream);  
      MemberList m = new MemberList();
      m = (MemberList) objectInputFile.readObject();
      objectInputFile.close();
      return m;
      
   }
   
   public void writeLecturers(LecturerList list) throws IOException {
      outStream = new FileOutputStream("Lecturer.bin");
      objectOutputFile = new ObjectOutputStream(outStream);
      objectOutputFile.writeObject(list);
      objectOutputFile.close();
   }
   
   public LecturerList readLecturers() throws IOException, ClassNotFoundException {
      inStream = new FileInputStream("Lecturer.bin");
      objectInputFile = new ObjectInputStream(inStream);  
      LecturerList l = new LecturerList();
      l = (LecturerList) objectInputFile.readObject();
      objectInputFile.close();
      return l;
   }
   
   public void writeSponsors(SponsorList list) throws IOException {
      outStream = new FileOutputStream("Sponsor.bin");
      objectOutputFile = new ObjectOutputStream(outStream);
      objectOutputFile.writeObject(list);
      objectOutputFile.close();
   }
   
   public SponsorList readSponsors() throws IOException, ClassNotFoundException {
      inStream = new FileInputStream("Sponsor.bin");
      objectInputFile = new ObjectInputStream(inStream);  
      SponsorList s = new SponsorList();
      s = (SponsorList) objectInputFile.readObject();
      objectInputFile.close();
      return s;
   }
}
