import java.util.ArrayList;
import java.io.Serializable;
public class Seminar extends Event implements Serializable
{
   private String subject;
   
   public Seminar(String name, Date date) {
      super(name,date);
   }
   public String getSubject() {  
      return subject;
   }
   public void setSubject(String subject) {
      this.subject = subject;
   }
   public boolean equals(Object obj) {
      if(!(obj instanceof Seminar)) {
         return false;
      }
      else {
         Seminar other = (Seminar) obj;
         return true;
      }
   }
   public String toString() {
      return super.toString() + ", Subject: " + getSubject();
   }
   public Date getEndDate() {
      return new Date(1,1,1);
   }
   public String getDestination() {
      return"";
   }
}
