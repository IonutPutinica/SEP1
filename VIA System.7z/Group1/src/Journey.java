import java.io.Serializable;
public class Journey extends Event implements Serializable
{
   private Date endDate;
   private String destination;
   
   public Journey(String name, Date date) {
      super(name,date);
   }
   public Date getEndDate() {
      return endDate;
   }
   public void setEndDate(Date date) {
      endDate = date;
   }
   public boolean equals(Object obj) {
      if(!(obj instanceof Journey)) {
         return false;
      }
      else {
         Journey other = (Journey) obj;
         return true;
      }
   }
   public String toString() {
      return super.toString() + ", Ending date: " + endDate;
   }
   public String getSubject() {
      return "";
   }
   public String getDestination() {
      return destination;
   }
   public void setDestination(String destination) {
      this.destination = destination;
   }
   
}
