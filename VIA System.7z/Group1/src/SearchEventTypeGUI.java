import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
public class SearchEventTypeGUI extends JFrame
{
   private JButton searchWorkshop;
   private JButton searchSeminar;
   private JButton searchJourney;
   private JButton searchLecture;
   
   public SearchEventTypeGUI() {
      super("Search Event");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() {
      searchWorkshop = new JButton("Workshop");
      searchSeminar = new JButton("Seminar");
      searchJourney = new JButton("Journey");
      searchLecture = new JButton("Lecture");
   }
   
   private void initializeComponents() {
      setSize(600,200);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   
   private void registerEventHandlers(){
      ButtonHandler handler = new ButtonHandler();
      searchLecture.addActionListener(handler);
      searchWorkshop.addActionListener(handler);
      searchSeminar.addActionListener(handler);
      searchJourney.addActionListener(handler);
   }
   private void  addComponentsToFrame() {
      JPanel main = new JPanel(new GridLayout(1,4));
      main.add(searchLecture);
      main.add(searchSeminar);
      main.add(searchWorkshop);
      main.add(searchJourney);
      
      setContentPane(main);
   }
   
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == searchLecture) {
            try
            {
               dispose();
               SearchLectureGUI sl = new SearchLectureGUI();
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == searchSeminar) {
            dispose();
            try
            {
               SearchSeminarGUI ss = new SearchSeminarGUI();
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == searchWorkshop) {
            dispose();
            try
            {
               SearchWorkshopGUI sw = new SearchWorkshopGUI();
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == searchJourney) {
            dispose();
            try
            {
               SearchJourneyGUI sj = new SearchJourneyGUI();
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
      }
   }
}