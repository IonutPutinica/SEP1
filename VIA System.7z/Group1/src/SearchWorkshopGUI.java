import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class SearchWorkshopGUI extends JFrame
{
   private JList workshopsList;
   private JRadioButton finalized;
   private JRadioButton nonFinalized;
   private JRadioButton both;
   private ButtonGroup buttonGroup;
   private JButton edit;
   private JButton delete;
   private String[] eList;
   private JScrollPane lecturePane;
   
   public SearchWorkshopGUI() throws ClassNotFoundException, IOException{
      super("Search Workshop");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() throws ClassNotFoundException, IOException {
      CompanyFile file = new CompanyFile();
      eList = new String[file.readEvents().getWorkshops().length];
      eList = file.readEvents().returnWorkshops();
      workshopsList = new JList(eList);
      lecturePane = new JScrollPane(workshopsList);
      workshopsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      workshopsList.setLayoutOrientation(JList.VERTICAL);
      workshopsList.setVisibleRowCount(10);
      lecturePane.setPreferredSize(new Dimension(420, 320));
      finalized = new JRadioButton("Finalized");
      nonFinalized = new JRadioButton("Non-finalized");
      both = new JRadioButton("Show all");
      edit = new JButton("Edit");
      delete = new JButton("Delete");
      buttonGroup = new ButtonGroup();
      buttonGroup.add(both);
      buttonGroup.add(finalized);
      buttonGroup.add(nonFinalized);
      both.setSelected(true);
   }
   private void initializeComponents() {
      setSize(550,400);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      finalized.addActionListener(handler);
      nonFinalized.addActionListener(handler);
      both.addActionListener(handler);
      edit.addActionListener(handler);
      delete.addActionListener(handler);
      workshopsList.addListSelectionListener(new ListSelectionListener() {
         @Override
         public void valueChanged(ListSelectionEvent e)
         {
            if(buttonGroup.getSelection().equals(finalized)) {
               try
               {
                  CompanyFile file = new CompanyFile();
                  EventList list = new EventList();
                  for(int i = 0;i < file.readEvents().returnFinalized().length;i++) {
                     if(file.readEvents().returnFinalized()[i].equals(new Workshop("asd", new Date(1,1,1)))) {
                        list.addEvent(file.readEvents().returnFinalized()[i]);
                     }
                  }
                  eList = new String[list.getEvents().length];
                  for(int i = 0;i < list.getEvents().length;i++) {   
                        eList[i] = list.getEvents()[i].returnWorkshop();
                  }
                  workshopsList.setListData(eList);
               }
               catch (ClassNotFoundException | IOException e1)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            if(buttonGroup.getSelection().equals(nonFinalized)) {
               try
               {
                  CompanyFile file = new CompanyFile();
                  EventList list = new EventList();
                  for(int i = 0;i < file.readEvents().returnNonFinalized().length;i++) {
                     if(file.readEvents().returnNonFinalized()[i].equals(new Workshop("asd", new Date(1,1,1)))) {
                        list.addEvent(file.readEvents().returnNonFinalized()[i]);
                     }
                  }
                  eList = new String[list.getEvents().length];
                  for(int i = 0;i < list.getEvents().length;i++) {   
                        eList[i] = list.getEvents()[i].returnWorkshop();
                  }
                  workshopsList.setListData(eList);
               }
               catch (ClassNotFoundException | IOException e2)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            if(buttonGroup.getSelection().equals(both)) {
               CompanyFile file = new CompanyFile();
               try
               {
                  workshopsList.setListData(file.readEvents().returnWorkshops());
               }
               catch (ClassNotFoundException | IOException e3)
               {
                  JOptionPane.showMessageDialog(null,"Something went wrong :(");
               }
            }
            
         }
      });
   }
   private void addComponentsToFrame() {
      JPanel list = new JPanel(new FlowLayout());
      JPanel buttonBox = new JPanel(new GridLayout(0,1));
      JPanel main = new JPanel(new BorderLayout());
      
      //list
      list.add(lecturePane);
      //buttonBox
      buttonBox.add(finalized);
      buttonBox.add(nonFinalized);
      buttonBox.add(both);
      buttonBox.add(edit);
      buttonBox.add(delete);
      //main
      main.add(list, BorderLayout.WEST);
      main.add(buttonBox, BorderLayout.EAST);
      
      setContentPane(main);
   }
   
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == finalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnFinalized().length;i++) {
                  if(file.readEvents().returnFinalized()[i].equals(new Workshop("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnWorkshop();
               }
               workshopsList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == nonFinalized) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               for(int i = 0;i < file.readEvents().returnNonFinalized().length;i++) {
                  if(file.readEvents().returnNonFinalized()[i].equals(new Workshop("asd", new Date(1,1,1)))) {
                     list.addEvent(file.readEvents().returnNonFinalized()[i]);
                  }
               }
               String[] eList = new String[list.getEvents().length];
               for(int i = 0;i < list.getEvents().length;i++) {   
                     eList[i] = list.getEvents()[i].returnWorkshop();
               }
               workshopsList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == both) {
            CompanyFile file = new CompanyFile();
            try
            {
               String[] eList = file.readEvents().returnWorkshops();
               workshopsList.setListData(eList);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == edit) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = new EventList();
               list = file.readEvents();
               for(int i = 0; i < list.getWorkshops().length;i++) {
                  if(workshopsList.getSelectedValue().equals(list.returnWorkshops()[i])) {
                     if(list.getWorkshops()[i].isFinalized()==true) {
                        JOptionPane.showMessageDialog(null,"Event is finalized.");
                     }
                     else {
                     CreateWorkshopGUI cw = new CreateWorkshopGUI();
                     cw.setName(list.getWorkshops()[i].getName());
                     cw.setSubject(list.getWorkshops()[i].getSubject());
                     cw.setEventDay(list.getWorkshops()[i].getDate().getDay());
                     cw.setEventMonth(list.getWorkshops()[i].getDate().getMonth());
                     cw.setEventYear(list.getWorkshops()[i].getDate().getYear());
                     cw.setEventEndDay(list.getWorkshops()[i].getEndDate().getDay());
                     cw.setEventEndMonth(list.getWorkshops()[i].getEndDate().getMonth());
                     cw.setEventEndYear(list.getWorkshops()[i].getEndDate().getYear());
                     cw.setEventHour(list.getWorkshops()[i].getScheduledTime().getHour());
                     cw.setEventMinute(list.getWorkshops()[i].getScheduledTime().getMinute());
                     cw.setLocation(list.getWorkshops()[i].getLocation());
                     cw.setEventDurationHour(list.getWorkshops()[i].getDuration().getHour());
                     cw.setEventDurationMinute(list.getWorkshops()[i].getDuration().getMinute());
                     cw.setMemberLimit(list.getWorkshops()[i].getMemberLimit());
                     cw.setEventPrice(list.getWorkshops()[i].getPrice());
                     cw.setEdit(false);
                     list.removeEvent(list.getWorkshops()[i]);
                     file.writeEvents(list);
                     }
                  }
               }
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
         if(event.getSource() == delete) {
            try
            {
               CompanyFile file = new CompanyFile();
               EventList list = file.readEvents();
               for(int i = 0; i < list.getWorkshops().length;i++) {
                  if(workshopsList.getSelectedValue().toString().equals(list.returnWorkshops()[i]) && list.getWorkshops()[i].equals(new Workshop("asd", new Date(1,1,1))))
                  {
                        list.removeEvent(list.getWorkshops()[i]);
                        eList = new String[list.returnWorkshops().length];
                        eList = list.returnWorkshops();
                        workshopsList.setListData(eList);
                        break;
                  }
               }
               file.writeEvents(list);
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose an event.");
            }
         }
      }
   }
}
