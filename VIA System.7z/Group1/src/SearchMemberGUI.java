import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


public class SearchMemberGUI extends JFrame 
{
   private JList<String> memberList;           //list to display members
   private JRadioButton paid;
   private JRadioButton nonPaid;
   private JRadioButton both;
   private ButtonGroup buttonGroup;    //group to hold radio buttons
   private JButton edit;
   private JButton delete;
   private MemberList mList;      //memberList object to hold data from file
   private JScrollPane scrollPane;
   
   public SearchMemberGUI() throws ClassNotFoundException, IOException{
      super("Search Member");
      createComponents();
      initializeComponents();
      registerEventHandlers();
      addComponentsToFrame();
   }
   
   private void createComponents() throws ClassNotFoundException, IOException {
      CompanyFile memberFile = new CompanyFile();        
      mList = memberFile.readMembers();                  
      memberList = new JList(mList.returnMembers());
      memberList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      memberList.setLayoutOrientation(JList.VERTICAL);
      memberList.setVisibleRowCount(10);
      scrollPane = new JScrollPane(memberList);
      scrollPane.setPreferredSize(new Dimension(500, 320));
      paid = new JRadioButton("Paid");
      nonPaid = new JRadioButton("Non-paid");
      both = new JRadioButton("Show all");
      buttonGroup = new ButtonGroup();
      buttonGroup.add(paid);
      buttonGroup.add(nonPaid);
      buttonGroup.add(both);
      both.setSelected(true);
      edit = new JButton("Edit");
      delete = new JButton("Delete");
   }
   private void initializeComponents() {
      setSize(600,400);
      setVisible(true);
      setLocationRelativeTo(null);
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   }
   private void registerEventHandlers() {
      ButtonHandler handler = new ButtonHandler();
      paid.addActionListener(handler);
      nonPaid.addActionListener(handler);
      both.addActionListener(handler);
      edit.addActionListener(handler);
      delete.addActionListener(handler);
   }
   private void addComponentsToFrame() {
      JPanel list = new JPanel(new FlowLayout());
      JPanel buttonBox = new JPanel(new GridLayout(0,1));
      JPanel main = new JPanel(new BorderLayout());
      
      //list
      list.add(scrollPane);
      //buttonBox
      buttonBox.add(paid);
      buttonBox.add(nonPaid);
      buttonBox.add(both);
      buttonBox.add(edit);
      buttonBox.add(delete);
      //main
      main.add(list, BorderLayout.WEST);
      main.add(buttonBox, BorderLayout.EAST);
      
      setContentPane(main);
   }
   private class ButtonHandler implements ActionListener{
      public void actionPerformed(ActionEvent event) {
         if(event.getSource() == nonPaid) {
            CompanyFile file = new CompanyFile();
            try
            {
               mList = file.readMembers();
               memberList.setListData(mList.returnNonPaidMembers());
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == paid) {
            CompanyFile file = new CompanyFile();
            try
            {
               mList = file.readMembers();
               memberList.setListData(mList.returnPaidMembers());
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == both) {
            CompanyFile file = new CompanyFile();
            try
            {
               mList = file.readMembers();
               memberList.setListData(mList.returnMembers());
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
         }
         if(event.getSource() == delete) {
            try
            {
               String str = memberList.getSelectedValue();
               CompanyFile memberFile = new CompanyFile();
               MemberList list = new MemberList();
               list = memberFile.readMembers();
               for(int i = 0; i < list.getMembers().length;i++) {
                  if(str.equals(list.returnMembers()[i])) {
                     list.removeMember(list.getMembers()[i]);
                  }
               }
               memberFile.writeMembers(list);
               mList = list;
               if(both.isSelected() == true) {
                  memberList.setListData(mList.returnMembers());
               }
               else if(paid.isSelected() == true) {
                  memberList.setListData(mList.returnPaidMembers());
               }
               else if(nonPaid.isSelected() == true) {
                  memberList.setListData(mList.returnNonPaidMembers());
               }
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose a member.");
            }
         }
         if(event.getSource() == edit) {
            try
            {
               CompanyFile memberFile = new CompanyFile();
               MemberList list = new MemberList();
               list = memberFile.readMembers();
               for(int i = 0; i < list.getMembers().length;i++) {
                  if(memberList.getSelectedValue().equals(list.returnMembers()[i])) {
                     CreateMemberGUI cm = new CreateMemberGUI();
                     cm.setName(list.getMembers()[i].getName());
                     cm.setPhone(list.getMembers()[i].getPhoneNumber());
                     cm.setEmail(list.getMembers()[i].getEmailAdress());
                     cm.setMembershipDay(list.getMembers()[i].getDateMembership().getDay());
                     cm.setMembershipMonth(list.getMembers()[i].getDateMembership().getMonth());
                     cm.setMembershipYear(list.getMembers()[i].getDateMembership().getYear());
                     cm.setPaymentYear(list.getMembers()[i].getPaymentYear());
                     cm.setEdit(false);
                     list.removeMember(list.getMembers()[i]);
                     memberFile.writeMembers(list);
                  }
               }
               
            }
            catch (ClassNotFoundException | IOException e)
            {
               JOptionPane.showMessageDialog(null,"Something went wrong :(");
            }
            catch (NullPointerException e) {
               JOptionPane.showMessageDialog(null, "Please choose a member.");
            }
         }
      }
   }
}
