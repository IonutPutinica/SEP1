import java.util.ArrayList;
import java.io.Serializable;
/**
 * A child class of Event, that stores information for
 * events of type Workshop
 * @author Group1
 *
 */
public class Workshop extends Event implements Serializable
{
   private String subject;
   private Date endDate;
   /**
    * A two argument constructor that calls the super() constructor.
    * @param String name
    * @param Date date
    */
   public Workshop(String name, Date date){
      super(name,date);
   }
   /**
    * A method that returns event ending date of type Date object.
    * @return Date
    */
   public Date getEndDate() {
      return endDate;
   }
   /**
    * A method that sets event ending date of type Date object
    * @param Date date
    */
   public void setEndDate(Date date) {
      endDate = date;
   }
   /**
    * A method that returns event subject
    * @return String
    */
   public String getSubject() {
      return subject;
   }
   /**
    * A method that sets event subject
    * @param String subject
    */
   public void setSubject(String subject) {
      this.subject = subject;
   }
   /**
    * A method that shows if the object passed as argument is of type Workshop.
    * @param Object object
    */
   public boolean equals(Object obj) {
      if(!(obj instanceof Workshop)) {
         return false;
      }
      else {
         Workshop other = (Workshop) obj;
         return true;
      }
   }
   /**
    * A method that calls the super.toString() method and adds Workshop specific
    * attributes to it in a String format.
    * @return String
    */
   public String toString() {
      return super.toString() + ", Ending date: " + endDate + ", Subject: " + getSubject();
   }
   /**
    * A method that returns event destination
    * @return String
    */
   public String getDestination() {
      return"";
   }
}
